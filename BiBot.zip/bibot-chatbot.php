<?php
/*
Plugin Name: BiBot Chatbot
Plugin URI:  https://bibot.app/
Description: Easily integrate the BiBot chatbot into your WordPress site.
Version:     1.0
Author:      CloudSec LLC
Author URI:  https://thecloudsecllc.com/
License:     GPL2
*/

function bibot_enqueue_scripts() {
    if (!is_admin()) {
        wp_enqueue_script('bibot-chatbot', plugin_dir_url(__FILE__) . 'dist/bibot-chatbot.bundle.js', [], '1.0', true);
    }

    $bibot_settings = array(
        'clientId' => get_option('bibot_client_id'),
        'redirectNotice' => get_option('bibot_redirect_notice') ? true : false,
        'test' => get_option('bibot_test_mode') ? true : false,
        'internalUserOnly' => array(
            'internalUseOnly' => get_option('bibot_internal_use_only') ? true : false,
            'jwt' => is_user_logged_in() && get_option('bibot_internal_use_only') ? wp_create_nonce('wp_rest') : null
        ),
    );
    wp_localize_script('bibot-chatbot', 'bibotSettings', $bibot_settings);
}
add_action('wp_enqueue_scripts', 'bibot_enqueue_scripts');

// Enqueue admin styles
function bibot_admin_styles() {
    wp_enqueue_style('bibot-admin-styles', plugin_dir_url(__FILE__) . 'css/bibot-admin.css', [], '1.0');
}
add_action('admin_enqueue_scripts', 'bibot_admin_styles');

// Create the BiBot settings menu
function bibot_create_menu() {
    add_options_page(
        'BiBot Chatbot Settings',
        'BiBot Chatbot',
        'manage_options',
        'bibot-chatbot-settings',
        'bibot_settings_page'
    );
}
add_action('admin_menu', 'bibot_create_menu');

// Display the settings page
function bibot_settings_page() {
    $logo_url = plugin_dir_url(__FILE__) . 'assets/logo.png'; // Path to the logo
    ?>
    <div class="wrap">
        <div class="bibot-header">
            <img src="<?php echo esc_url($logo_url); ?>" alt="BiBot Logo" class="bibot-logo" />
            <h1>BiBot Chatbot Settings</h1>
        </div>
        <form method="post" action="options.php" class="bibot-form">
            <?php
            settings_fields('bibot-settings-group');
            do_settings_sections('bibot-settings-group');
            ?>
            <table class="form-table">
                <tr valign="top">
                    <th scope="row"><label for="bibot_client_id">Client ID <span class="required">(REQUIRED)</span></label></th>
                    <td><input type="text" id="bibot_client_id" name="bibot_client_id" value="<?php echo esc_attr(get_option('bibot_client_id')); ?>" class="regular-text" required /></td>
                </tr>

                <tr valign="top">
                    <th scope="row"><label for="bibot_redirect_notice">Redirect Notice <span class="optional">(OPTIONAL)</span></label></th>
                    <td><input type="checkbox" id="bibot_redirect_notice" name="bibot_redirect_notice" value="1" <?php checked(1, get_option('bibot_redirect_notice'), true); ?> /></td>
                </tr>

                <tr valign="top">
                    <th scope="row"><label for="bibot_test_mode">Test Mode <span class="optional">(OPTIONAL)</span></label></th>
                    <td><input type="checkbox" id="bibot_test_mode" name="bibot_test_mode" value="1" <?php checked(1, get_option('bibot_test_mode'), true); ?> /></td>
                </tr>

                <tr valign="top">
                    <th scope="row"><label for="bibot_internal_use_only">Internal Use Only <span class="required">(REQUIRED jwt-field if enabled)</span></label></th>
                    <td><input type="checkbox" id="bibot_internal_use_only" name="bibot_internal_use_only" value="1" <?php checked(1, get_option('bibot_internal_use_only'), true); ?> /></td>
                </tr>
            </table>
            <script type="text/javascript">
                document.getElementById('bibot_internal_use_only').addEventListener('change', function() {
                    var jwtField = document.getElementById('jwt-field');
                    if (this.checked) {
                        jwtField.style.display = 'table-row';
                    } else {
                        jwtField.style.display = 'none';
                    }
                });
            </script>
            <?php submit_button(); ?>
        </form>
    </div>
    <?php
}

// Register settings
function bibot_register_settings() {
    register_setting('bibot-settings-group', 'bibot_client_id');
    register_setting('bibot-settings-group', 'bibot_client_session_id');
    register_setting('bibot-settings-group', 'bibot_redirect_notice');
    register_setting('bibot-settings-group', 'bibot_test_mode');
    register_setting('bibot-settings-group', 'bibot_internal_use_only');
}
add_action('admin_init', 'bibot_register_settings');
