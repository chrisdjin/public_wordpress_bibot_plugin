import React from 'react';
import ReactDOM from 'react-dom';
import { BiBot } from 'bibot';

document.addEventListener('DOMContentLoaded', function() {
    const clientId = bibotSettings.clientId;
    const redirectNotice = bibotSettings.redirectNotice;
    const test = bibotSettings.test;
    const internalUseOnly = bibotSettings.internalUserOnly.internalUseOnly;
    const jwt = bibotSettings.internalUserOnly.jwt;

    const chatbotContainer = document.createElement('div');
    chatbotContainer.id = 'bibot-chatbot';
    document.body.appendChild(chatbotContainer);

    ReactDOM.render(
        <BiBot 
            clientId={clientId}
            redirect_notice={redirectNotice}
            test={test}
            internalUserOnly={{
                internalUseOnly: internalUseOnly,
                jwt: internalUseOnly ? jwt : null
            }}
        />,
        document.getElementById('bibot-chatbot')
    );
});
